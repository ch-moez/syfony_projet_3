<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* test.html */
class __TwigTemplate_d84fd556f852e7e0c6ae72eb09eb3a225706022443c9fada674f8837fc6486d1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "test.html"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "test.html"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">
    <meta name=\"Description\" content=\"Enter your description here\" />
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css\">
    <link rel=\"stylesheet\" href=\"assets/css/style.css\">
    <title>Title</title>
</head>

<body>

    <div class=\"row\">

        <div class=\"col-md-3\">
            <a href=\"\">
                <img class=\"img-fluid\" src=\"http://placehold.it/350x150\">
            </a>
            <h3>Titre de produit</h3>
            <a class=\"btn\"></a>
        </div>

        <div class=\"col-md-3\">
            <a href=\"\">
                <img class=\"img-fluid\" src=\"http://placehold.it/350x150\">
            </a>
            <h3>Titre de produit</h3>
            <a class=\"btn\"></a>
        </div>

        <div class=\"col-md-3\">
            <a href=\"\">
                <img class=\"img-fluid\" src=\"http://placehold.it/350x150\">
            </a>
            <h3>Titre de produit</h3>
            <a class=\"btn\"></a>
        </div>

    </div>
    <!--  end row -->

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js\"></script>
</body>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "test.html";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">

<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">
    <meta name=\"Description\" content=\"Enter your description here\" />
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css\">
    <link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css\">
    <link rel=\"stylesheet\" href=\"assets/css/style.css\">
    <title>Title</title>
</head>

<body>

    <div class=\"row\">

        <div class=\"col-md-3\">
            <a href=\"\">
                <img class=\"img-fluid\" src=\"http://placehold.it/350x150\">
            </a>
            <h3>Titre de produit</h3>
            <a class=\"btn\"></a>
        </div>

        <div class=\"col-md-3\">
            <a href=\"\">
                <img class=\"img-fluid\" src=\"http://placehold.it/350x150\">
            </a>
            <h3>Titre de produit</h3>
            <a class=\"btn\"></a>
        </div>

        <div class=\"col-md-3\">
            <a href=\"\">
                <img class=\"img-fluid\" src=\"http://placehold.it/350x150\">
            </a>
            <h3>Titre de produit</h3>
            <a class=\"btn\"></a>
        </div>

    </div>
    <!--  end row -->

    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.slim.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js\"></script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/js/bootstrap.min.js\"></script>
</body>

</html>", "test.html", "C:\\wamp64\\www\\symfonyProjectTest\\test_3\\templates\\test.html");
    }
}
